namespace LojaPOO.Models;

public class Cliente
{
    public int Id { get; set; }
    public string Nome { get; set; }
    public string Email { get; set; }

    public void Exibir()
    {
        Console.WriteLine($"ID: {Id} | Nome: {Nome} | Email: {Email}");
    }
}